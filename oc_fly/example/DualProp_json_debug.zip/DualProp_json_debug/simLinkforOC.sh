#!/bin/bash
ln -s /home/tms/CommunityNoise/OpenCOPTER/oc_fly/oc_fly oc_fly
