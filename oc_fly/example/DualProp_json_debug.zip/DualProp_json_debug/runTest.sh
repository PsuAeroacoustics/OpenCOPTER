#!/bin/bash
python3 oc_fly -input_geom TilterLifter.json5 -input_param TilterLifter_params.json5 --aero -ws > ocFly.log & tail -f ocFly.log
