#!/bin/bash
python3 oc_fly -input_geom notional_evtol.json5 -input_param notional_evtol_params.json5 --aero > ocFly.log & tail -f ocFly.log
